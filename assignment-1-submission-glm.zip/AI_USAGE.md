# AI Usage Disclosure

I used the following AI systems while completing this assignment.

## OpenAI Codex

I used Codex as an interactive programming assistant throughout the assignment. It helped me:

- interpret the assignment requirements and grading criteria;
- explain the agent loop, tool schemas, context compaction, chess state handling, and sandbox execution;
- review and debug code that I wrote in `src/assignment/agent/`;
- design local mock tests for tool validation, error handling, state updates, and stateless simulation;
- inspect generated trajectories and results;
- calculate experiment metrics and draft the reports in `artifacts/`;
- audit the final submission for missing files, parse errors, and accidental credential inclusion.

I reviewed the suggested changes, entered or approved the implementation, ran the required experiments, and retained responsibility for the submitted code and conclusions.

## DeepSeek Flash

I used DeepSeek Flash through an OpenAI-compatible API as a model for the chess-agent experiments. It generated chess tool calls for the legal-move and board-only observation conditions and produced the programmatic chess trajectory that loaded the `select-move` skill, executed Python search code using `simulate_move`, and committed moves using `play_move`.

## GLM-4.5-Air

I used GLM-4.5-Air through the Zhipu OpenAI-compatible API as the second model in the observation comparison. It generated chess tool calls for both the legal-move and board-only observation conditions. The resulting trajectories and metrics were compared with the DeepSeek Flash runs in `artifacts/observation-experiment.md`.

## Supporting infrastructure

The model experiments ran in the assignment's Modal sandbox and used the provided OpenAI-compatible client interface. Modal was execution infrastructure rather than a source of generated assignment content. No API keys or other credentials are included in the submission.
