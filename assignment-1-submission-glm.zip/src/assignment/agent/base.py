"""The domain-independent ReAct loop shared by both agents.

Part 1 completes the generic loop here; the two subclasses in this package
supply only their own tools and tool executors.
"""  # 文档字符串

# 两个 Agent 共同使用的、与具体领域无关的 ReAct 循环。
# Part 1 在这里实现通用的循环逻辑；这个 package 中的两个子类只需要提供各自的工具（tools）
# 和工具执行器（tool executors）。

from __future__ import annotations

from copy import deepcopy
import json
import logging
import math
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from openai import OpenAI

from assignment.env import Environment
from assignment.agent.tools import INVOKE_SKILL_TOOL

import yaml

load_dotenv()
logger = logging.getLogger(__name__)

DEFAULT_COMPACTION_KEEP_RECENT_STEPS = 1
DEFAULT_COMPACTION_MAX_TOKENS = 1_200
MAX_OBSERVATION_CHARS = 10_000

# TODO(Part 2): Write instructions that make the model produce concise working
# memory for a software agent. The prompt should preserve concrete progress,
# failures, test results, constraints, and next steps without copying raw output.
COMPACTION_SYSTEM_PROMPT = """
你负责：将软件代理较早的交互记录整理为简洁、事实性的工作记忆，供代理继续完成当前任务。
必须保留：
- 任务目标
- 约束和要求
- 检查过的文件
- 执行过的命令
- 已完成的修改
- 命令和测试的具体结果
- 失败的方法及其原因
- 当前阻塞
- 下一步行动
要求：
- 只使用历史记录中已经出现的事实。
- 不得虚构历史中没有的信息
- 不要继续解决原始任务
- 不要调用工具
- 不要复制大段终端输出
- 只输出工作记忆
"""


class StepLimitError(Exception):
    """Raised when an agent exhausts its model-call budget."""


def format_tool_output(output: dict[str, Any]) -> str:
    """Format a terminal result as a compact, tagged model observation."""

    elements: list[str] = []
    for key in sorted(output):
        value = output[key]
        if isinstance(value, str) and len(value) > MAX_OBSERVATION_CHARS:
            # Leave room for the elision notice so the formatted value itself,
            # not just its retained source slices, stays below the limit.
            retained_at_each_end = 4_900
            omitted = len(value) - (2 * retained_at_each_end)
            value = (
                f"{value[:retained_at_each_end]}\n"
                f"[{omitted} characters elided; read a narrower range]\n"
                f"{value[-retained_at_each_end:]}"
            )
        elements.append(f"<{key}>{value}</{key}>")
    return "\n".join(elements)


def rough_message_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate prompt tokens without a provider-specific tokenizer."""

    serialized = json.dumps(messages, ensure_ascii=False, separators=(",", ":"))
    return max(1, math.ceil(len(serialized) / 4))


class Agent:
    """Base class for a ReAct agent with pluggable tools."""

    def __init__(
        self,
        environment: Environment,
        model: str | None = None,
        logs_save_path: str | None = None,
        step_limit: int = 100,
        skills_path: str | None = None,
        auto_stop_environment: bool = True,
        compact_threshold_tokens: int | None = None,
        compaction_keep_recent_steps: int = DEFAULT_COMPACTION_KEEP_RECENT_STEPS,
        compaction_max_tokens: int = DEFAULT_COMPACTION_MAX_TOKENS,
    ):
        self.env = environment
        self.model = model or os.environ.get("OPENAI_MODEL")
        if not self.model:
            raise RuntimeError("OPENAI_MODEL is not set.")

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not set.")
        base_url = os.environ.get("OPENAI_BASE_URL")
        if not base_url:
            raise RuntimeError("OPENAI_BASE_URL is not set.")
        try:
            max_retries = int(os.environ.get("OPENAI_MAX_RETRIES", "5"))
        except ValueError as exc:
            raise RuntimeError("OPENAI_MAX_RETRIES must be an integer.") from exc
        if max_retries < 0:
            raise RuntimeError("OPENAI_MAX_RETRIES must be non-negative.")

        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            max_retries=max_retries,
        )

        self.logs_save_path = logs_save_path
        self.step_limit = step_limit
        self.auto_stop_environment = auto_stop_environment
        if compact_threshold_tokens is not None and compact_threshold_tokens <= 0:
            raise ValueError("compact_threshold_tokens must be positive or None")
        if (
            compaction_keep_recent_steps is not None
            and compaction_keep_recent_steps < 1
        ):
            raise ValueError("compaction_keep_recent_steps must be at least 1")
        if compaction_max_tokens is not None and compaction_max_tokens < 1:
            raise ValueError("compaction_max_tokens must be positive")
        # A None threshold turns compaction off. The other two settings then
        # describe a compaction that never happens, so fall back to the
        # defaults rather than leaving a None for later code to trip over.
        self.compact_threshold_tokens = compact_threshold_tokens
        self.compaction_keep_recent_steps = (
            DEFAULT_COMPACTION_KEEP_RECENT_STEPS
            if compaction_keep_recent_steps is None
            else compaction_keep_recent_steps
        )
        self.compaction_max_tokens = (
            DEFAULT_COMPACTION_MAX_TOKENS
            if compaction_max_tokens is None
            else compaction_max_tokens
        )

        # Each agent supplies its own opening messages: the standing
        # instructions, and the task statement that starts the run.
        self.system_prompt: str = ""
        self.task_prompt: str = ""

        self.api_prompts: list[list[dict[str, Any]]] = []
        self.api_responses: list[dict[str, Any]] = []
        self.compaction_events: list[dict[str, Any]] = []
        self.tools: list[dict[str, Any]] = []
        self.finished = False
        self.steps_taken = 0

        self.skills_path = Path(skills_path) if skills_path is not None else None
        self.skills: dict[str, dict[str, str]] = (
            self.load_skills(self.skills_path) if self.skills_path is not None else {}
        )

        if self.skills:
            self.tools.append(INVOKE_SKILL_TOOL)

        # TODO(1.1.a): Add machinery to maintain agent state as it takes actions
        # and observes the results.
        self.history: list[dict[str, Any]] = []

    # TODO(1.4): Validate ``skills_path``, discover one ``SKILL.md``
    # per child directory, parse its YAML frontmatter (what's between the
    # `---` tags at the head of the file), and return a mapping
    # keyed by the frontmatter ``name``. Each value must contain a concise
    # ``metadata`` string for the model's skill catalog and the complete
    # ``content`` of the skill file for ``invoke_skill``. Reject duplicate
    # names and malformed or missing frontmatter with a clear
    # ``ValueError``.
    def load_skills(self, skills_path: Path) -> dict[str, dict[str, str]]:
        """Load the skill folders exposed to this agent."""
        if not skills_path.is_dir():
            raise ValueError(f"skill路径不是文件夹:{skills_path}")

        result: dict[str, dict[str, str]] = {}

        skill_files: list[Path] = []
        for (
            child
        ) in skills_path.iterdir():  # skill_path-遍历code_skills下的每一个文件夹
            if child.is_dir():  # child-submit_task,里面都是skill
                skill_file = child / "SKILL.md"
                if skill_file.is_file():
                    skill_files.append(skill_file)
                else:
                    raise ValueError(f"缺少技能文件: {skill_file}")
        for skill_file in skill_files:
            content = skill_file.read_text(encoding="utf-8")
            content_list = content.splitlines()

            if not content_list or content_list[0] != "---":
                raise ValueError(f"缺少开头的 YAML 分隔线: {skill_file}")
            if "---" not in content_list[1:]:
                raise ValueError(f"缺少结尾的 YAML 分隔线: {skill_file}")

            end = content_list.index("---", 1)  # 要找的值，从索引1开始找
            frontmatter_text = "\n".join(content_list[1:end])

            try:
                frontmatter = yaml.safe_load(frontmatter_text)
            except yaml.YAMLError:
                raise ValueError(f"YAML 格式损坏: {skill_file}")

            if not isinstance(frontmatter, dict):
                raise ValueError(f"YAML 格式合法但不是字典: {skill_file}")

            name = frontmatter.get("name")
            description = frontmatter.get("description")
            if not isinstance(name, str) or not name.strip():
                raise ValueError(f"技能 name 缺失或不是非空字符串: {skill_file}")

            if not isinstance(description, str) or not description.strip():
                raise ValueError(f"技能 description 缺失或不是非空字符串: {skill_file}")

            if name in result:
                raise ValueError(f"技能名称重复: {name}，文件: {skill_file}")

            result[name] = {
                "metadata": f"name: {name}\ndescription: {description}",
                "content": content,
            }

        return result

    def query_language_model(self) -> dict[str, Any]:
        """Send one tool-enabled Chat Completions request and normalize it."""

        messages = self.build_prompt()  # 得到发给模型的消息列表

        self.api_prompts.append(deepcopy(messages))
        step_number = self.steps_taken + 1
        print(
            f"[agent] step {step_number}/{self.step_limit}: requesting action",
            flush=True,
        )
        try:
            response = self.client.chat.completions.create(  # 把messages发送给LLM，得到原始response
                model=self.model,
                messages=messages,
                tools=self.tools,
                reasoning_effort="low",
                max_completion_tokens=4096,
            )
        except Exception as exc:
            print(
                f"[agent] step {step_number}: model request failed after retries "
                f"({type(exc).__name__}: {exc})",
                flush=True,
            )
            raise
        self.api_responses.append(response.model_dump(mode="json"))
        self.steps_taken += 1
        message = self.process_response(
            response
        )  # 从原始 response 中整理出模型刚刚生成的这一条 assistant message：
        # 不是单纯的一句话，而是一个比较大的对象，里面除了模型生成的消息，还可能有模型名称、usage、finish reason 等信息。
        tool_names = [
            call.get("function", {}).get("name", "unknown")
            for call in message.get("tool_calls", [])
            if isinstance(call, dict)
        ]
        if tool_names:
            print(
                f"[agent] step {step_number}: tool call(s): {', '.join(tool_names)}",
                flush=True,
            )
        else:
            print(
                f"[agent] step {step_number}: response contained no parsed tool call; "
                "the loop should preserve the response and continue",
                flush=True,
            )
        return message

    def process_response(self, response: Any) -> dict[str, Any]:
        """Return relevant parts of the language model's response."""
        # 从第一个候选回答 choices[0] 中，取出模型本轮生成的 assistant message。比如：
        #         {  并把 SDK 的 Message 对象转换成 Python 字典，供 Agent 后续读取 content、tool_calls 等信息。
        #     "role": "assistant",
        #     "content": "I need to inspect the repository first.",
        #     "tool_calls": [
        #         {
        #             "id": "call_123",
        #             "function": {
        #                 "name": "execute",
        #                 "arguments": "{\"command\":\"ls\"}"
        #             }
        #         }
        #     ]
        # }
        return response.choices[0].message.model_dump(exclude_none=True)

    def build_prompt(
        self,
    ) -> list[dict[str, Any]]:  # 构造一系列 message,组成最终发送给大语言模型的 prompt。
        # TODO(1.1.a): Construct a sequence of messages that form the language
        # model prompt. This should include standing instructions, task
        # specification, prior interaction including observations, reasoning,
        # and actions from previous turns. Note that this method should be
        # domain-agnostic and construct the prompt in a way that would apply
        # to any of the inheriting domain-specific agents.

        messages: list[dict[str, Any]] = []
        messages.append({"role": "system", "content": self.system_prompt})
        messages.append({"role": "user", "content": self.task_prompt})

        messages.extend(
            self.history
        )  # 这里把两个存放字典类型的列表拼接起来时用的extend 不能直接append 否则会加一个列表进去
        # extend(x)：遍历 x 把 x 里面的元素逐个加入列表。 append(x)：把 x 本身作为一个元素加入列表。
        # You want to be careful about which attributes of the class you modify
        # here as they may also be handled by the subclasses.
        return messages  # 固定开头 + 不断增长的交互历史

    def estimate_active_prompt_tokens(
        self,
    ) -> int:  # 即将进行的这一次模型请求，其输入提示大约会占多少 token。
        #         这个输入提示包含当前仍然有效的全部上下文：
        #         system prompt
        # + 原始任务 task prompt
        # + self.history 中当前保留的历史
        """Estimate the next prompt, calibrated by the provider's latest usage."""

        current_prompt = self.build_prompt()
        rough_current = rough_message_tokens(current_prompt)
        if not self.api_prompts or not self.api_responses:
            return rough_current

        usage = self.api_responses[-1].get("usage") or {}
        actual_previous = usage.get("prompt_tokens")
        if not isinstance(actual_previous, int):
            return rough_current

        rough_previous = rough_message_tokens(self.api_prompts[-1])
        added_since_previous_request = max(0, rough_current - rough_previous)
        return actual_previous + added_since_previous_request

    @property  # 这是一个属性 当前这个 Agent 是否配置了压缩阈值？
    def compaction_enabled(self) -> bool:
        """Whether this agent compacts its context at all."""

        # compact_threshold_tokens = None  # 关闭压缩
        # compact_threshold_tokens = 6000  # 开启，达到约 6000 tokens 时压缩
        return self.compact_threshold_tokens is not None

    # 当其为空是返回false ，意思是不用压缩

    def compact_context(self):
        """Replace parts of prompt with model-generated working memory. Changes the
        content that `build_prompt` emits."""

        # TODO(2.1): Prompt the model to compact the context. The system
        # prompt should ask for concise factual working memory and preserve
        # the objective, constraints, files, commands, edits, concrete
        # results, failed approaches, tests, blockers, and next action.
        # Summarize only an old prefix; retain the original system/task
        # messages verbatim and at least the latest complete assistant action
        # with all linked tool observations. The resulting summary should change
        # what `build_prompt` emits, and reduce the length of the prompt.

        # 同时获得索引和元素：message是里面的一个个字典，将每个字典打上索引

        assistant_indices = [
            index
            for index, message in enumerate(self.history)
            if message.get("role") == "assistant"
        ]  # 推导式，用来保存assistant行动的索引

        split_index = assistant_indices[
            -self.compaction_keep_recent_steps
        ]  # 得到指定轮的assistant的索引
        # 当然是正向的索引数，后面进行历史分割

        history_to_summarize = self.history[
            :split_index
        ]  # 索引前面的是要压缩的消息列表
        recent_history = self.history[split_index:]

        ##下面要构造压缩素材
        compaction_source = [
            {"role": "system", "content": self.system_prompt},  # 原始 Agent 系统提示；
            {"role": "user", "content": self.task_prompt},  # 原始任务；
            *history_to_summarize,  # 这里相当于compaction_source.extend(history_to_summarize)
        ]

        compaction_prompt = [  # 构造真正发给压缩模型的消息
            {
                "role": "system",
                "content": COMPACTION_SYSTEM_PROMPT,  # 刚写的 COMPACTION_SYSTEM_PROMPT
            },
            {
                "role": "user",
                "content": json.dumps(
                    compaction_source, ensure_ascii=False
                ),  # 这里就是要压缩的内容了
            },  # json.dumps把 Python 的消息列表转换成一段 JSON 文本；ensure_ascii=False 让中文保持为中文，而不是转换成 \u4efb\u52a1。
        ]

        ### Do not modify this section ###
        compaction_response = (
            self.client.chat.completions.create(  # 调用模型发送压缩请求
                model=self.model,
                messages=compaction_prompt,
                reasoning_effort="medium",
                max_completion_tokens=self.compaction_max_tokens,
            )
        )
        ##################################

        # Use `compaction_response` to update what `build_prompt` emits, but
        # DO NOT modify the object itself. Let the method return it unchanged.

        summary = compaction_response.choices[0].message.content  # 摘要
        if (
            not isinstance(summary, str) or not summary.strip()
        ):  # 验证模型返回非空字符串
            raise RuntimeError("上下文压缩模型没有返回有效的工作记忆")

        working_memory = {  # 构造工作记忆消息
            "role": "user",  # 角色使用user提供给 Agent 的已有背景信息。
            "content": (
                "<working_memory>\n" f"{summary.strip()}\n" "</working_memory>"
            ),
        }

        self.history = [working_memory, *recent_history]
        ### Do not modify this section ###
        return compaction_prompt, compaction_response.model_dump(mode="json")
        ################################## 
        # compaction_prompt的主要用途是记录和调试
        # 第二个返回值compaction_response是 OpenAI SDK 返回的对象为了能写入 JSON 轨迹文件，代码将它转换成普通字典
        # 实际影响下一次模型请求的不是这两个返回值，而是你在函数中已经完成的状态修改
        # 修改 self.history：真正完成上下文压缩；
        # 返回两个值：保存本次压缩的审计记录。

    def maybe_compact_context(self) -> bool:
        """Compact before the next action request when the threshold is reached."""
        # 启用压缩有这三个条件
        if not self.compaction_enabled:  # 是否启用上下文压缩
            return False  # 本次没有压缩，也没有调用压缩模型

        # Context too short to compact yet
        if self.estimate_active_prompt_tokens() < self.compact_threshold_tokens:
            return False  # 估算token是否达到阈值，若没有达到则不压缩

        prompt_before = deepcopy(
            self.build_prompt()
        )  # 保存压缩前的提示，后面与压缩后对比

        # Not enough steps (each assistant turn corresponds to a step) to force
        # compaction yet
        if (
            len([m for m in prompt_before if m.get("role") == "assistant"])
            <= self.compaction_keep_recent_steps
        ):  # 判断是否 存在可压缩的 步骤，若没有则返回False不压缩
            return False

        compaction_prompt, compaction_response = self.compact_context()  # 执行压缩

        prompt_after = deepcopy(self.build_prompt())  # 获取压缩后的提示

        self.compaction_events.append(
            # 记录压缩事件压缩发生在第几步；
            # 压缩前后的估算长度；
            # 压缩前的完整提示；
            # 发给压缩模型的消息；
            # 压缩模型的完整响应及 token 用量。
            {
                "step": self.steps_taken,
                "estimated_tokens_before": rough_message_tokens(prompt_before),
                "estimated_tokens_after": rough_message_tokens(prompt_after),
                "active_prompt_before": deepcopy(prompt_before),
                "compaction_prompt": compaction_prompt,
                "compaction_response": compaction_response,
            }
        )
        return True  # 本次已经完成压缩

    def run(self) -> None:
        """Run ReAct steps, always saving the trajectory and stopping Modal."""

        try:  # ReAct loop

            # TODO(1.2) Run the ReAct loop. Orchestrate the sequence of
            # prompting the language model to produce reasoning and actions,
            # extracting the tool calls produced by the model, and executing 提取工具调用信息并执行
            # the tool calls to obtain the agent's observation for the next
            # step. Ensure you identify when the agent has completed the task
            # by setting `Agent.finished`. If the agent exceeds the
            # `step_limit`, raise `StepLimitError`.
            while not self.finished:

                if self.steps_taken >= self.step_limit:
                    raise StepLimitError("Agent exceeded its step limit.")
                # return → 结束整个函数，并且可以返回结果  break  → 只结束当前循环  continue → 跳过本轮循环，进入下一轮
                # raise  → 抛出异常，正常执行流程中断
                # break

                # TODO(2.2) 判断当前上下文是否需要压缩；满足条件时调用 compact_context() 自动完成压缩。
                self.maybe_compact_context()

                assistant_message = (
                    self.query_language_model()
                )  # assistant_message 自己是一个 dict
                self.history.append(assistant_message)

                tool_calls = (
                    assistant_message.get(  # tool_calls 这个 key 对应的字典列表
                        "tool_calls", []
                    )
                )  # 字典.get(key, default)要查找的 key; 如果找不到这个 key 返回默认值
                if tool_calls:
                    observations = self.execute_tool_calls(
                        tool_calls
                    )  # executing the tool calls,obtain the agent's observati  on
                    self.history.extend(observations)

            # TODO(2.2) Call `maybe_compact_context()` before each new action
            # request in your shared loop. It already estimates active tokens
            # and handles the threshold, and tracks compaction events for
            # logging.

        finally:  # 保存日志并关闭环境 无论 try 中是正常结束还是发生异常，都必须执行这里的清理代码。
            # This block is provided infrastructure. Do not modify it: a
            # trajectory is required even when a run fails.
            if self.logs_save_path:
                path = Path(self.logs_save_path)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(
                    json.dumps(
                        {
                            "prompts": self.api_prompts,
                            "responses": self.api_responses,
                            "compactions": self.compaction_events,
                        },
                        indent=2,
                    )
                )
            if self.auto_stop_environment:
                stop = getattr(self.env, "stop", None)
                if callable(stop):
                    stop()

    def execute_tool_calls(
        self, tool_calls: list[dict[str, Any]]
    ) -> list[dict[str, str]]:
        """Execute domain-specific calls and return linked tool observations."""

        # You do not need to implement anything here. This method is
        # domain-specific and implemented by the relevant subclasses
        raise NotImplementedError
