"""The Part 1 coding agent: fix a software issue and submit a git patch."""

from __future__ import annotations

import json
from typing import Any

from assignment.agent.base import (
    DEFAULT_COMPACTION_KEEP_RECENT_STEPS,
    DEFAULT_COMPACTION_MAX_TOKENS,
    Agent,
    format_tool_output,
)
from assignment.agent.tools import EXECUTE_TOOL, SEND_MESSAGE_TOOL
from assignment.env import Environment


class CodeAgent(Agent):
    """An agent that fixes a software issue and submits a git patch."""

    def __init__(
        self,
        task: str,
        environment: Environment,
        model: str | None = None,
        logs_save_path: str | None = None,
        step_limit: int = 100,
        skills_path: str | None = None,
        auto_stop_environment: bool = True,
        compact_threshold_tokens: int | None = None,
        compaction_keep_recent_steps: int = DEFAULT_COMPACTION_KEEP_RECENT_STEPS,
        compaction_max_tokens: int = DEFAULT_COMPACTION_MAX_TOKENS,
    ):
        super().__init__(
            environment=environment,
            model=model,
            logs_save_path=logs_save_path,
            step_limit=step_limit,
            skills_path=skills_path,
            auto_stop_environment=auto_stop_environment,
            compact_threshold_tokens=compact_threshold_tokens,
            compaction_keep_recent_steps=compaction_keep_recent_steps,
            compaction_max_tokens=compaction_max_tokens,
        )

        self.task = task  # 把传进来的信息保存成实例属性
        self.submitted_patch = ""

        # TODO(Part 1.3): Make the `execute` and `send_message` tools available
        # to the agent.让 CodeAgent 调用 LLM 时，模型知道自己有 execute 和 send_message 两个工具可以使用。
        # 把 execute 和 send_message 的 schema 注册给模型；
        # 如果不注册，LLM 就不会知道 execute 和 send_message 是可以调用的工具。
        # 注册工具-注意Agent类中有一个self.tools属性，在query中这个属性会通过调用API传给模型

        self.tools.append(EXECUTE_TOOL)
        self.tools.append(SEND_MESSAGE_TOOL)

        # TODO(1.1.b):
        # 构造 system_prompt 和 task_prompt，并且它们应该能被 Agent.build_prompt() 使用
        system_information = {
            "machine": self.env.machine,
            "release": self.env.release,  # 读取真实沙箱信息,env实例属性定义在Agent类中
            "system": self.env.system,
            "version": self.env.version,
        }
        system_information_json = json.dumps(
            system_information, indent=2
        )  # 转为str：Python 对象 → JSON 字符串

        self.system_prompt = (  # 保存长期工作指令；
            "你是一个编程智能体，你的任务是在终端中解决软件问题"
            "\n\n<system_information>\n"
            f"{system_information_json}\n"
            "</system_information>"
        )
        if self.skills:
            catalog_parts: list[str] = []

            for skill in self.skills.values():
                catalog_parts.append(skill["metadata"])
            catalog = "\n\n".join(catalog_parts)
            self.system_prompt += (
                "\n\n以下是可用技能的简介。需要完整说明时，"
                "调用 invoke_skill 并传入技能的 name。\n"
                f"{catalog}"
            )

        self.task_prompt = (
            task  # 这里的task是在创建CodeAgent时传进来的参数  保存本次具体任务；
        )

        # TODO(1.4): If any skills are available to the agent, make their
        # descriptions/metadata available to the agent in the prompt.

    def execute_tool_calls(
        self, tool_calls: list[dict[str, Any]]
    ) -> list[dict[str, str]]:
        """Execute ``execute`` and ``send_message`` calls in the code sandbox."""

        # TODO(Part 1.3): Parse each call, execute recognized tools, and return
        # one message per call (there may be multiple tool calls in one agent
        # response!). Malformed JSON and unknown tools must become recoverable
        # observations relayed to the agent instead of exceptions.
        # #实现 execute_tool_calls()，解析并执行模型返回的调用。
        # 遍历模型产生的所有 tool call → 解析参数 → 判断是什么工具 → 真正执行 → 把执行结果转换成 observation 返回；
        # JSON 格式错误和未知工具不能让程序直接崩掉，而要作为 observation 告诉 Agent。

        observations: list[dict[str, str]] = []

        for tool_call in tool_calls:
            tool_function = tool_call.get("function", {})
            tool_name = tool_function.get("name", "")
            tool_call_id = tool_call.get("id", "")

            try:
                tool_arguments = json.loads(
                    tool_function.get("arguments")
                )  # 由json-str变成python字典
            except (json.JSONDecodeError, TypeError) as exc:
                observations.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": f"工具参数非法: {exc}",
                    }
                )
                continue
            if not isinstance(tool_arguments, dict):  # 不是字典
                observations.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": "工具参数必须是一个 JSON object.",
                    }
                )
                continue

            if tool_name == "execute":
                output = self.env.execute(**tool_arguments)  # ???
                formatted_output = format_tool_output(output)
                observations.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": formatted_output,
                    }
                )
            elif tool_name == "send_message":
                summary = tool_arguments.get("summary")

                if not isinstance(summary, str):
                    observations.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call_id,
                            "content": "summary必须是字符串",
                        }
                    )
                    continue

                self.finished = True
                observations.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": summary,
                    }
                )
            elif tool_name == "invoke_skill":
                skill_name = tool_arguments.get("name")
                if not isinstance(skill_name, str) or not skill_name.strip():  # 参数不是非空字符串，返回错误 observation
                    observations.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call_id,
                            "content": "技能名必须是非空字符串",
                        }
                    )
                elif skill_name not in self.skills:  # 没有这个技能，返回错误 observation
                    observations.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call_id,
                            "content": f"未知技能: {skill_name}",
                        }
                    )
                else:
                    content = self.skills[skill_name]["content"]
                    observations.append(
                        {
                            "role": "tool",
                            "tool_call_id": tool_call_id,
                            "content": content,
                        }
                    )
            else:  # 未知工具分支
                observations.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call_id,
                        "content": f"未知工具调用:{tool_name}",
                    }
                )
        return observations


# {    这是 assistant_message ;     tool calls  =  assistant_message.get("tool_calls", [])
#     "role": "assistant",
#     "tool_calls": [#字典列表， 上面的循环就是遍历这个列表 tool_call就是其中的一个个字典
#         {
#             "id": "call_xxx",
#             "type": "function",
#             "function": {
#                 "name": "execute",
#                 "arguments": "{\"command\":\"ls\"}"
#             }
#         }

#         {
#             "id": "call_xxx",
#             "type": "function",
#             "function": {
#                 "name": "execute",
#                 "arguments": "{\"command\":\"ls\"}"
#             }
#         }
#
#     ]
# }
