"""Tool definitions exposed to the model, in the OpenAI tool-calling format."""
#大python字典

EXECUTE_TOOL = {
    "type": "function",
    
    "function": {
        #给你一个工具，名字叫 execute，作用是执行 Bash 命令。
        "name": "execute",
        "description": (
            "Run a bash command and return its stdout, stderr, and exit code. "
            "A non-zero exit code is reported, not raised.\n"
            "\n"
            "Every command runs in a new subshell, so a `cd` or an export does not "
            "carry over to the next command. Use the `cwd` and `env` arguments "
            "instead. Files you write do persist.\n"
            "\n"
            "Commands are non-interactive and cannot prompt for input, so pass "
            "flags like `-y` where a command would otherwise ask for confirmation. "
            "Prefer commands that produce little output; when reading a file, use "
            "`head`, `tail`, or `sed -n '10,20p'` rather than printing all of it.\n"
            "\n"
            "Useful patterns:\n"
            "- Create a file: `cat <<'EOF' > newfile.py` ... `EOF`\n"
            "- Edit in place: `sed -i 's/old/new/g' filename.py` (drop the trailing "
            "`g` to replace only the first match; restrict to a line range with "
            "`sed -i '1,10s/old/new/g'`)\n"
            "- View numbered lines: `nl -ba filename.py | sed -n '10,20p'`"
        ),
        # The nested env object intentionally accepts arbitrary variable names,
        # which is incompatible with strict schemas on some providers.
        "strict": False,
        
        #parameters 是告诉模型：如果你要调用 execute，你可以/需要给我哪些参数。
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "anyOf": [
                        {
                            "type": "string",
                            "description": 'A shell command line, e.g. "ls -la | head".',
                        },
                        {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                'The command as an argv list, e.g. ["ls", "-la"]. '
                                "Use this with shell=false when arguments contain "
                                "characters the shell would interpret."
                            ),
                        },
                    ],
                    "description": "The command to run.",
                },
                "shell": {
                    "type": ["boolean", "null"],
                    "description": (
                        "Whether to run the command through a shell, which enables "
                        "pipes, redirection, and globbing. Defaults to true. Set to "
                        "false when passing an argv list."
                    ),
                },
                "cwd": {
                    "type": ["string", "null"],
                    "description": (
                        "Absolute path to run the command in. Defaults to the "
                        "sandbox's current working directory."
                    ),
                },
                "timeout": {
                    "type": ["number", "null"],
                    "description": (
                        "Seconds to allow the command to run before killing it. "
                        "Defaults to no timeout."
                    ),
                },
                "env": {
                    "type": ["object", "null"],
                    "additionalProperties": {"type": "string"},
                    "description": "Extra environment variables to set for this command.",
                },
            },
            "required": ["command"],
            "additionalProperties": False,
        },
    },
}

SEND_MESSAGE_TOOL = {
    "type": "function",
    "function": {
        "name": "send_message",
        "description": ("Send a message to the user."),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "summary": {
                    "type": "string",
                    "description": ("Content of the message"),
                },
            },
            "required": ["summary"],
            "additionalProperties": False,
        },
    },
}

INVOKE_SKILL_TOOL = {
    "type": "function",
    "function": {
        "name": "invoke_skill",
        "description": (
            "Load a skill and return its instructions. A skill is a short guide "
            "for one kind of work, written ahead of time.\n"
            "\n"
            "Call this before starting work a skill covers, and follow what it "
            "says in place of your default approach."
        ),
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "The skill's directory name, for example `hello-skill`."
                    ),
                },
            },
            "required": ["name"],
            "additionalProperties": False,
        },
    },
}

# TODO(3.1.a): Define an OpenAI function-tool schema named ``play_move``.
# It must accept exactly one required string argument named ``move``, explain
# that moves use UCI notation (for example e2e4), and reject extra arguments.
PLAY_MOVE_TOOL: dict = {
    "type": "function",#填写工具类型，告诉模型这是一个函数工具
    "function": {
        "name": "play_move",#填写函数工具名称
        "description": "Play one legal move as White on the live chess board using UCI notation." ,#填写工具整体说明
        "strict": True,#要求模型按照后续定义的参数结构生成调用；填写布尔值。同时配合 additionalProperties: False，避免模型自行添加参数。
        "parameters": {
            "type": "object",#填写参数整体类型
            "properties": {#定义对象中允许出现的字段。这里仅允许move
                "move": {
                    "type": "string",#填写 move 的类型
                    "description": (        #填写 move 的说明和示例,
                        "The move in UCI notation, for example `e2e4`, or `e7e8q` "
                        "when promoting a pawn to a queen."
                    )  
                }
            },
            "required": ["move"],#填写必需参数
            "additionalProperties":False,# 填写是否允许额外参数 这里不允许；禁止模型增加其他字段
        },
    },
}

# TODO(3.3): Define the `simulate_move` tool, like the `play_move` tool.
SIMULATE_MOVE_TOOL: dict = {
    "type":"function",
    "function":{
        "name":"simulate_move",
        "description":(
            "Inspect a chess position or simulate exactly one move without "#可以检查一个指定棋局；
            "changing the live game."#可以假设执行一步棋，但不会改变正在进行的真实棋局。
        ),
        "strict": True,
        "parameters":{
            "type":"object",#整个工具参数必须是 JSON 对象
            "properties":{
                "fen":{
                    "type":"string",
                    "description":(
                        "A complete six-field FEN string describing the "
                        "position to inspect."
                    ),
                },
                "move":{
                    "type":["string","null"],
                    "description":(
                        "An optional move in UCI notation, such as `e2e4` or "
                        "`e7e8q`. Use null to inspect the FEN without making "
                        "a simulated move."
                    ),
                },
            } ,
            "required": ["fen", "move"],
            "additionalProperties": False,
        },
            
    }
    
    
     
}

# TODO()
RUN_PYTHON_TOOL: dict = {
    "type":"function",
    "function":{
        "name":"run_python",
        "description":(
            "在沙箱中执行 Python 代码；代码可以直接调用 simulate_move() 和 play_move()"
        ),
        "strict":True,
        "parameters":{
            "type":"object",
            "properties":{
                
                "code":{
                    "type":"string",
                    "description":(
                        "需要在沙箱中运行的 Python 代码"
                    )    
                }
                
            },
            "required":["code"],
            "additionalProperties": False,  
        },
        
    }
   
}
