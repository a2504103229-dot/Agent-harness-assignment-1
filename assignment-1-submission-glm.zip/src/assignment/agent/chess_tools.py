"""Chess tool implementations, decoupled from the agent that registers them.

Every function here takes the HTTP client explicitly instead of reading it off
an agent, so the same code can run in the agent process or inside the sandbox
beside the server it talks to.
"""

from __future__ import annotations

import base64
import json
from typing import Any

import httpx

CHESS_PORT = 8000


def _request_state(
    client: httpx.Client, method: str, endpoint: str, **kwargs: Any
) -> dict[str, Any]:
    """Make one chess API request and validate its JSON response."""

    response = client.request(method, endpoint, **kwargs)#ChessAgent发送 HTTP 请求Chess Server
    #并得到Chess Server 的 JSON 响应
    try:
        payload = response.json()#HTTP响应里的JSON → Python对象
    except ValueError as exc:
        raise RuntimeError(
            f"Chess server returned non-JSON ({response.status_code})."
        ) from exc
    if response.status_code >= 400:
        detail = (
            payload.get("detail", payload) if isinstance(payload, dict) else payload
        )
        raise ValueError(str(detail))
    if not isinstance(payload, dict):
        raise RuntimeError("Chess server response must be a JSON object.")
    return payload


#输入是模型生成的 JSON 字符串，成功时返回服务器状态的 JSON 字符串；失败时返回错误信息
def _simulate_move(client: httpx.Client, arguments: str) -> str:
    """New tool: inspect FEN or simulate one ply without changing the game.

    Takes the raw JSON arguments of one tool call and returns the observation
    to send back, so a bad argument or a server error reaches the model as a
    recoverable ``<chess_error>`` instead of ending the run.
    """
    try:
    
        payload = json.loads(arguments)
        
        if not isinstance(payload,dict):
            raise ValueError("工具调用的信息不是字典")
        
        if set(payload.keys()) - {"fen", "move"}:
            raise ValueError("参数列表中含有除fen和move之外的其他字段")
        
        fen = payload.get("fen")
        move = payload.get("move")
        
        if not isinstance(fen,str) or not  fen.strip():
            raise ValueError("参数fen错误")
        if move is not None:
            if not isinstance(move, str) or not move.strip():
                raise ValueError("参数move错误")

        state = _request_state(
                    client,
                    "POST",
                    "/api/simulate",
                    json={"fen": fen,"move": move},#move = "e2e4"
                )
        return json.dumps(state)
    
    except Exception as exc:
        return f"<chess_error>{exc}</chess_error>"
    
    
    
    
    
    # TODO(Part 3.3.b): Parse the arguments, call the provided
    # /api/simulate endpoint with fen and optional move, and return its JSON.
    # Catch any errors raised by the tool and return an error message between
    # `<chess_error></chess_error>` for the agent to address. Cover malformed
    # JSON arguments, arguments that are not an object, a missing or
    # non-string fen, a non-string move, a position or move the server rejects,
    # and a transport failure.
   

            #这传进来的是LLM的请求调用工具的信息；
def _play_move(client: httpx.Client, arguments: str) -> str:#希望传进来的 client 是一个 httpx.Client 对象。
            #就是一个已经创建好的HTTP客户端,后面用它向象棋客户端发送请求，如client.post(...)
    """Existing tool: play one move as White and return the resulting state.

    Takes the raw JSON arguments of one tool call. Returns the new state, or a
    `<chess_error>` observation if the move could not be played.
    """
    
    try:                                 #{"move": "e2e4"}
        payload = json.loads(arguments)#这里传进来的参数是一个json字符串，后面要解析为python字典
    
        if not isinstance(payload,dict):
            raise ValueError("工具调用的信息不是字典")
        
        move = payload.get("move")
        
        if not isinstance(move,str):
            raise ValueError("参数move不是字符串类型")
        if not move.strip():
            raise ValueError("参数 move 不能为空")
        if set(payload.keys())!= {"move"}:
            raise ValueError("参数列表中含有除move之外的其他字段")
            
        state = _request_state(
            client,
            "POST",
            "/api/move",
            json={"move": move},#move = "e2e4"
        )
        
        #state = Chess Server 在白棋执行 move、黑棋响应之后返回的最新棋局状态
        return json.dumps(state)#字典-json
        
    
    except Exception as exc:
        return f"<chess_error>{exc}</chess_error>"
    
   
    
    # TODO(3.1.b): Parse the arguments and POST {"move": <uci move>} to
    # /api/move. Return its JSON object. Catch any errors raised by the
    # tool and return an error message between `<chess_error></chess_error>`
    # for the agent to address. Cover malformed JSON arguments, arguments
    # that are not an object, a missing or non-string fen, a non-string move,
    # a position or move the server rejects, and a transport failure.
    


def _run_python(env: Any, port: int, arguments: str) -> str:
    """New tool: run Python with access to the existing registered tools.

    The snippet runs inside the sandbox, which already has the tool
    implementations and the chess server, so code the model wrote never
    executes in the agent process.
    """
    try:
        payload = json.loads(arguments)
        if not isinstance(payload,dict):
            raise ValueError("工具调用的信息不是字典")
        if set(payload.keys())!= {"code"}:
            raise ValueError("参数列表中含有除code之外的其他字段")
                
        code = payload.get("code")
        if not isinstance(code,str):
            raise ValueError("参数code不是字符串类型")
                
        encoded = base64.b64encode(code.encode()).decode()
        command = [
            "python",
            "/opt/assignment/sandbox_python.py",
            str(port),
            encoded,
        ]
        result = env.execute(command, shell=False)
        
        if result["returncode"] != 0:
            message = (
                result.get("exception_info")
                or result.get("stderr")
                or result.get("output")
                or "Sandbox command failed."
            )
            return f"<chess_error>{message}</chess_error>"

        return result["output"]
        
    
    except Exception as exc:
        return f"<chess_error>{exc}</chess_error>"
    
    
    
    
    # TODO(3.4): parse the arguments and run the code in the
    # sandbox with the registered tools available by name.
    #
    # `/opt/assignment/sandbox_python.py` is a script on the `env` sandbox
    # that has access to the same tool definitions in this file. Use it to run
    # the code that the model produced as an argument to the run_python tool.
    # The script accepts two positional arguments -- `port` and a base64-encoded
    # string of code (to prevent issues with quoting). Implement this tool
    # call.
    #
    # The script prints one JSON object with `stdout`, `stderr`, and `error`
    # from running the code -- return that string as it is.
    #
    # A non-zero returncode means the sandbox itself failed, not the model's
    # code. Report `exception_info` or `stderr` as a <chess_error>.
    #
    # Return <chess_error>{message}</chess_error> if there are issues like type
    # mismatches or parsing failures.
    


def _invoke_skill(skills: dict[str, dict[str, str]], arguments: str) -> str:
    """Existing tool: load one skill's instructions into the conversation."""
    try:                                 
        payload = json.loads(arguments)
            
        if not isinstance(payload,dict):
            raise ValueError("工具调用的信息不是字典")
        if set(payload.keys())!= {"name"}:
            raise ValueError("参数列表中含有除name之外的其他字段")
            
        name = payload.get("name")
            
        if not isinstance(name,str) or not name.strip():
            raise ValueError("参数name类型错误")
            
        if name not in skills:
            raise ValueError(f"技能不存在: {name}")

        skill = skills[name]
        if not isinstance(skill, dict):
            raise ValueError(f"技能数据格式错误: {name}")

        content = skill.get("content")
        if not isinstance(content, str):
            raise ValueError(f"技能内容格式错误: {name}")
            
            
        return  content
            
        
    except Exception as exc:
            return f"<chess_error>{exc}</chess_error>"
        
    
    
    
    
    
    # TODO(3.5): parse the arguments and return the named skill's content.
    # Return <chess_error>{message}</chess_error> if there are issues like type
    # mismatches or parsing failures.
    


def _game_state(client: httpx.Client, reset: bool = False) -> dict:
    """Read the live game, or start a new one and read the opening position."""

    method, endpoint = ("POST", "/api/reset") if reset else ("GET", "/api/state")
    return _request_state(client, method, endpoint)
