# Observation A/B Experiment

## Objective

This experiment measures how the chess agent's observation interface affects
tool-use reliability. Each model was run under two conditions:

1. **Legal-move observation:** the board state, FEN, and the current
   `legal_moves` list were shown to the model.
2. **Board/FEN-only observation:** the same state was shown, but the
   `legal_moves` list was omitted, so the model had to infer legal moves.

The task, repaired chess application, deterministic Black bot, `play_move`
tool, 200-step limit, and sandbox configuration were otherwise held constant.
The two available models used for this run were `glm-4.5-air` and
`deepseek-flash`.

## Metrics

- **Play-move calls:** total model-generated calls whose function name was
  `play_move`.
- **Illegal calls:** unique tool observations explicitly rejected by the chess
  server with `is not legal in the current position`.
- **Invalid-move rate:** illegal calls divided by total `play_move` calls.
- **Game over:** the value of `game_over` in the final result artifact.

Tool observations were deduplicated by `tool_call_id` because every later
prompt contains prior conversation history. Transport errors were counted
separately and were not classified as illegal chess moves.

## Results

| Model | Observation | Model responses | `play_move` calls | Illegal calls | Invalid-move rate | `game_over` | Outcome | Plies | Transport errors |
|---|---|---:|---:|---:|---:|---|---|---:|---:|
| GLM-4.5-Air | Legal moves included | 35 | 35 | 1 | 2.86% | Yes | Black wins | 68 | 0 |
| GLM-4.5-Air | Board/FEN only | 200 | 31 | 11 | 35.48% | No | In progress; White in check | 40 | 1 |
| DeepSeek Flash | Legal moves included | 50 | 50 | 0 | 0.00% | Yes | Black wins | 62 | 19 |
| DeepSeek Flash | Board/FEN only | 31 | 30 | 0 | 0.00% | Yes | Black wins | 60 | 0 |

## Analysis

Providing legal moves materially improved GLM-4.5-Air's reliability. Its
invalid-move rate fell from 35.48% to 2.86%, and the legal-move run reached a
terminal state. Without the list, the model used all 200 response steps, made
only 31 `play_move` calls, and did not finish the game. This suggests that the
structured action list helped GLM translate its reasoning into valid tool
arguments and continue making progress.

DeepSeek Flash produced no chess-rule rejection in either condition and
reached a terminal state in both runs. In this sample, it inferred legal moves
from the board and FEN reliably enough that adding `legal_moves` did not reduce
the already-zero invalid-move rate.

The DeepSeek legal-move run encountered 19 Modal tunnel failures, including
timeouts, disconnects, and TLS handshake errors. The agent retried moves after
these failures, inflating its total call and response counts. Therefore, the
50-versus-30 call difference cannot be attributed to the observation condition.
The DeepSeek comparison supports a conclusion about legality and completion,
but not a clean conclusion about call efficiency.

All completed games ended in a Black win. Winning was not the target metric;
the experiment evaluates whether the agent produces legal tool calls and
reaches a terminal state. These are single stochastic runs, so the results
show behavior in these samples rather than stable estimates of chess strength.

## Evidence

- `artifacts/part3-legal-moves-glm-4.5-air.json`
- `artifacts/part3-legal-moves-glm-4.5-air-result.json`
- `artifacts/part3-no-legal-moves-glm-4.5-air.json`
- `artifacts/part3-no-legal-moves-glm-4.5-air-result.json`
- `artifacts/part3-legal-moves-deepseek.json`
- `artifacts/part3-legal-moves-deepseek-result.json`
- `artifacts/part3-no-legal-moves-deepseek.json`
- `artifacts/part3-no-legal-moves-deepseek-result.json`

## Submission note

The assignment's named second-model runner targets `openai/gpt-oss-120b`.
This experiment used GLM-4.5-Air as the second available provider model, so the
report and artifact names preserve the actual model identity rather than
presenting GLM output as GPT-OSS output.
