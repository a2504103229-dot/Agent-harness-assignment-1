# Token Usage Analysis

## Experimental setup

I ran the `django__django-15368` SWE-bench task twice with the same model (`glm-5.3-flash`), reasoning effort, 200-step limit, and code skills. The compacted run used a 6,000-token threshold, while the baseline disabled compaction. Both runs produced the same patch, and the patch passed the SWE-bench evaluation with `RESOLVED: yes`.

## Results

| Metric | Compacted run | No-compaction baseline |
|---|---:|---:|
| Agent action steps | 18 | 16 |
| Compaction events | 1 | 0 |
| Action prompt tokens | 62,492 | 71,011 |
| Action completion tokens | 1,694 | 1,665 |
| Compaction prompt tokens | 6,685 | 0 |
| Compaction completion tokens | 587 | 0 |
| Total input tokens, including compaction | 69,177 | 71,011 |
| Total tokens, including compaction | 71,458 | 72,676 |
| Peak action prompt tokens | 5,887 | 8,497 |

The compacted run triggered one compaction after action step 12. At that point, the estimated active prompt decreased from 6,784 to 1,483 tokens, a reduction of 5,301 tokens (78.1%). The next actual action prompt contained 2,415 tokens. Across the full run, the peak action prompt was 30.7% lower than the baseline peak.

Considering only action requests, compaction reduced prompt usage by 8,519 tokens, or about 12.0%. However, producing the working-memory summary required an additional 6,685 input tokens and 587 output tokens. After including this overhead, total input usage was 2.6% lower and total token usage was 1.7% lower than the baseline.

## Interpretation and tradeoffs

The clearest benefit was control of active context size. Replacing old interactions with a concise working memory prevented the prompt from continuing to grow and reduced the peak prompt from 8,497 to 5,887 tokens. This matters for long-running agents because it lowers the risk of exceeding the model's context window and leaves more space for later observations and actions.

Compaction also has costs. The summarization request consumes tokens, and a generated summary may omit details that become important later. Retaining the most recent complete assistant action and its linked tool observations reduces this risk, but it cannot remove it entirely. On a relatively short task such as this one, the one-time summarization cost offsets most of the prompt-token savings. A longer run would reuse the shorter working memory across more later actions and could therefore produce larger net savings.

The compacted run used 18 action steps, while the baseline used 16. Model generation is stochastic, so this difference does not establish that compaction caused additional steps. The identical patches and successful evaluation show that, in these runs, compaction preserved enough information to complete the task correctly while materially reducing peak active context.
